+-------------------------------------------+
� Vos extensions doivent avoir les deux     �
� lignes de code suivantes au d�but :       �
+-------------------------------------------+
� Your plugins must have the two following  �
� lines of code somewhere at the top:       �
+-------------------------------------------+

   SetTitleMatchMode, 2
   WinActivate, - Vic

