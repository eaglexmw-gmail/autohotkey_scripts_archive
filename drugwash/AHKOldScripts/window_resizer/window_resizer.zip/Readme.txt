---------------------------------------------------------------
Window Resizer
---------------------------------------------------------------
by David Barnes - www.softwareguider.110mb.com
Copyright 2009. All rights reserved.

In order for this script to function correctly, it must first be extracted from its zip archive.

Included in this zip file are: window_resizer.ahk, window_resizer.exe and window_resizer.ico
If you want to view and learn from the code, open window_resizer.ahk
Otherwise, I prefer using window_resizer.exe