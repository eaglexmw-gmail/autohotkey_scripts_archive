Here, some hacked up versions of AutoHotkey's AutoIt-legacy tools would go. Obviously they can't be stored on github.

File list:

- ASWHook.dll
- Au3Spy.exe
- AutoScriptWriter.exe
