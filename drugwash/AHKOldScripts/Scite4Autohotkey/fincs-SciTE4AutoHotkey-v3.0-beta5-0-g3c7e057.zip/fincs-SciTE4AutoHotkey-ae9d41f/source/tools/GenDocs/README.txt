Microsoft's HTML help compiler would go here.

File list:

- hha.dll
- hhc.exe
