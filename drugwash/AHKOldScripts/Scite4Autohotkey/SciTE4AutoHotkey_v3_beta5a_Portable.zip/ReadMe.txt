SciTE4AutoHotkey v3 beta 5 Portable Edition
===========================================

Thank you for downloading SciTE4AutoHotkey v3 beta 5.
Supported platforms: Windows XP SP2+, Vista, 7

For the best user experience, use AutoHotkey_L instead of AutoHotkey Basic.

Installation: unpack this archive to your AutoHotkey folder so that you have:

AutoHotkey
|_______ AutoHotkey.exe (can be either AutoHotkey_L or AutoHotkey Basic)
|_______ AutoHotkey.chm
|_______ SciTE_beta5
         |______ etc...

Side-by-side AutoHotkey_L builds (AutoHotkey_La.exe, _Lw.exe, _L64.exe and _L.chm) are also supported,
but they must be in a separate folder: %AhkDir%\AutoHotkey_L so that there is:

AutoHotkey
|________ AutoHotkey_L
|         |_____ AutoHotkey_L*.exe, .chm, etc
|
|________ SciTE_beta5