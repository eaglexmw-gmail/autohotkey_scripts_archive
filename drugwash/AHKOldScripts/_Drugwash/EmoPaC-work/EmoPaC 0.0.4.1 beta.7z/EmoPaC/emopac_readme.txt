EmoPaC - Miranda IM Emoticon Pack Creator by Drugwash
�April-May 2008

v0.0.4.1 beta

It should create emoticon packs (.mep signature file plus images, with or without protocol subfolders).
In Expert mode, it can also create .emo files, only useful for the developer of the Emoticons plug-in.

There are hotkeys:
CTRL + D - toggles 'debug' mode
CTRL + I - toggles the tray icon
CTRL + X - toggles 'expert' mode

AniGif.ahk and EmoPaC.ahk are the sources, written in AutoHotkey.
To run the program, just launch EmoPaC.exe.

Important: please do not remove noimg.ico from the 'data' folder, otherwise the image lists will display the wrong pictures.
AnGIF.dll is needed to display animated GIFs in the preview window.

There are unfinished options. Please read the changelog for the latest news.

Drugwash
May 3rd, 2008

