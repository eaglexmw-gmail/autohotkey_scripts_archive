EmoPaC - Miranda IM Emoticon Pack Creator by Drugwash
�April 2008

v0.0.3.6 alpha

It should create emoticon packs (.mep signature file plus images, with or without protocol subfolders).
In Expert mode, it can also create .emo files, only useful for the developer of the Emoticons plug-in.

AniGif.ahk and EmoPaC.ahk are the sources, written in AutoHotkey.
To run the program, just launch EmoPaC.exe.

Important: please keep the noimg.ico file in the same folder with the exe, otherwise the image lists will display the wrong pictures.
AnGIF.dll is needed to display animated GIFs in the preview window.

There are unfinished options. Please read the changelog for the latest news.

Drugwash
April 25, 2008

