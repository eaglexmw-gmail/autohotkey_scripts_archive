EmoPaC - Miranda IM Emoticon Pacl Creator by Drugwash
April 2008

-v0.0.3.1 alpha

AniGif.ahk and EmoPaC.ahk are the sources, written in AutoHotkey.
To run the program, just launch EmoPaC.exe.

Important: please keep the noimg1.ico file in the same folder with the exe, otherwise the image lists will display the wrong pictures.
AnGIF.dll is needed to display animated GIFs in the preview window. Other formats will not be displayed there.

There are unfinished options.
