/**
 * SyntaxHighlighter
 * http://alexgorbatchev.com/
 *
 * SyntaxHighlighter is donationware. If you are using it, please donate.
 * http://alexgorbatchev.com/wiki/SyntaxHighlighter:Donate
 *
 * @version
 * 2.1.364 (October 15 2009)
 * 
 * @copyright
 * Copyright (C) 2004-2009 Alex Gorbatchev.
 *
 * @license
 * This file is part of SyntaxHighlighter.
 * 
 * SyntaxHighlighter is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SyntaxHighlighter is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SyntaxHighlighter.  If not, see <http://www.gnu.org/copyleft/lesser.html>.
 */
SyntaxHighlighter.brushes.AHK = function()
{
	var commands  =	'AutoTrim BlockInput Break ClipWait Continue Control ControlClick ControlFocus ControlGet ControlGetFocus ControlGetPos ControlGetText ControlMove ControlSend ControlSendRaw ControlSetText CoordMode Critical DetectHiddenText DetectHiddenWindows Drive DriveGet DriveSpaceFree Edit Else EndRepeat EnvAdd EnvDiv EnvGet EnvMult EnvSet EnvSub EnvUpdate Exit ExitApp FileAppend FileCopy FileCopyDir FileCreateDir FileCreateShortcut FileDelete FileGetAttrib FileGetShortcut FileGetSize FileGetTime FileGetVersion FileInstall FileMove FileMoveDir FileRead FileReadLine FileRecycle FileRecycleEmpty FileRemoveDir FileSelectFile FileSelectFolder FileSetAttrib FileSetTime FormatTime GetKeyState Gosub Goto GroupActivate GroupAdd GroupClose GroupDeactivate Gui GuiControl GuiControlGet HideAutoItWin Hotkey If IfEqual IfExist IfGreater IfGreaterOrEqual IfInString IfLess IfLessOrEqual IfMsgBox IfNotEqual IfNotExist IfNotInString IfWinActive IfWinExist IfWinNotActive IfWinNotExist ImageSearch IniDelete IniRead IniWrite Input InputBox KeyHistory KeyWait ListHotkeys ListLines ListVars Loop Menu MouseClick MouseClickDrag MouseGetPos MouseMove MsgBox OnExit OutputDebug Pause PixelGetColor Pixelsearch PostMessage Process Progress Random RegDelete RegRead RegWrite Reload Repeat Return Run RunAs RunWait Send SendMessage SendRaw SendInput SetBatchLines SetCapsLockState SetControlDelay SetDefaultMouseSpeed SetEnv SetFormat SetKeyDelay SetMouseDelay SetNumLockState SetScrollLockState SetStoreCapslockMode SetTimer SetTitleMatchMode SetWinDelay SetWorkingDir Shutdown Sleep Sort SoundBeep SoundGet SoundGetWaveVolume SoundPlay SoundSet SoundSetWaveVolume SplashImage SplashTextOff SplashTextOn SplitPath StatusBarGetText StatusBarWait StringCaseSense StringGetPos StringLeft StringLen StringLower StringMid StringReplace StringRight StringSplit StringTrimLeft StringTrimRight StringUpper Suspend SysGet Thread ToolTip Transform TrayTip TV_Add TV_Modify TV_Delete TV_GetSelection TV_GetCount TV_GetParent TV_GetChild TV_GetPrev TV_GetNext TV_GetText TV_Get URLDownloadToFile WinActivate WinActivateBottom WinClose WinGet WinGetActiveStats WinGetActiveTitle WinGetClass WinGetPos WinGetText WinGetTitle WinHide WinKill WinMaximize WinMenuSelectItem WinMinimize WinMinimizeAll WinMinimizeAllUndo WinMove WinRestore WinSet WinSetTitle WinShow WinWait WinWaitActive WinWaitClose WinWaitNotActive';
	var special   = 'PIXEL MOUSE SCREEN RELATIVE RGB ahk_id ahk_pid ahk_class ahk_group Between Contains In Integer Float Number Digit Xdigit Alpha Upper Lower Alnum Time Date AlwaysOnTop Topmost Top Bottom Transparent TransColor Redraw Region ID IDLast ProcessName MinMax ControlList Count List Capacity StatusCD Eject Lock Unlock Label FileSystem Label SetLabel Serial Type Status static global local ByRef Seconds Minutes Hours Days Read Parse Logoff Close Error Single Tray Add Rename Check UnCheck ToggleCheck Enable Disable ToggleEnable Default NoDefault Standard NoStandard Color Delete DeleteAll Icon NoIcon Tip Click Show MainWindow NoMainWindow UseErrorLevel   Font Resize Owner Submit NoHide Minimize Maximize Restore NoActivate NA Cancel Destroy Center Text Picture Pic GroupBox Button Checkbox Radio DropDownList DDL ComboBox ListBox ListView DateTime MonthCal UpDown Slider Tab TabStop Section AltSubmit Wrap HScroll VScroll Border Top Bottom Buttons Number Uppercase Lowercase Limit Password Multi WantReturn Group Background Theme Caption Delimiter MinimizeBox MaximizeBox SysMenu ToolWindow Flash Style ExStyle Check3 Checked CheckedGray ReadOnly Password Hidden Left Right Center NoTab Section Move Focus Hide Choose ChooseString Text Pos Enabled Disabled Visible LastFound AltTab ShiftAltTab AltTabMenu AltTabAndMenu AltTabMenuDismiss NoTimers Interrupt Priority WaitClose {BLIND} {ALTDOWN} {ALTUP} {SHIFTDOWN} {SHIFTUP} {CTRLDOWN} {CTRLUP} {LWINDOWN} {RWINDOWN}   Unicode Asc Chr Deref Mod Pow Exp Sqrt Log Ln Round Ceil Floor Abs Sin Cos Tan ASin ACos ATan BitNot BitAnd BitOr BitXOr BitShiftLeft BitShiftRight Yes No Ok Cancel Abort Retry Ignore A_DetectHiddenText A_DetectHiddenWindows A_EndChar A_EventInfo A_ExitReason A_FormatFloat A_FormatInteger A_Gui A_GuiEvent A_GuiControl A_GuiControlEvent A_GuiHeight A_GuiWidth A_GuiX A_GuiY A_Hour A_IconFile A_IconHidden A_IconNumber A_IconTip A_Index A_IPAddress1 A_IPAddress2 A_IPAddress3 A_IPAddress4 A_ISAdmin A_IsCompiled A_IsSuspended A_KeyDelay A_Language A_LineFile A_LineNumber A_LoopField A_LoopFileAttrib A_LoopFileDir A_LoopFileExt A_LoopFileFullPath A_LoopFileLongPath A_LoopFileName A_LoopFileShortName A_LoopFileShortPath A_LoopFileSize A_LoopFileSizeKB A_LoopFileSizeMB A_LoopFileTimeAccessed A_LoopFileTimeCreated A_LoopFileTimeModified A_LoopReadLine A_LoopRegKey A_LoopRegName A_LoopRegSubkey A_LoopRegTimeModified A_LoopRegType A_MDAY A_Min A_MM A_MMM A_MMMM A_Mon A_MouseDelay A_MSec A_MyDocuments A_Now A_NowUTC A_NumBatchLines A_OSType A_OSVersion A_PriorHotkey A_ProgramFiles A_Programs A_ProgramsCommon A_ScreenHeight A_ScreenWidth A_ScriptDir A_ScriptFullPath A_ScriptName A_Sec A_Space A_StartMenu A_StartMenuCommon A_Startup A_StartupCommon A_StringCaseSense A_Tab A_ThisHotkey A_ThisMenu A_ThisMenuItem A_ThisMenuItemPos A_TickCount A_TimeIdle A_TimeIdlePhysical A_TimeSincePriorHotkey A_TimeSinceThisHotkey A_TitleMatchMode A_TitleMatchModeSpeed A_UserName A_WDay A_WinDelay A_WinDir A_WorkingDir A_YDay A_YEAR A_YWeek A_YYYY Clipboard ClipboardAll ErrorLevel True False';
	var keys	  = 'Shift {Shift} LShift {LShift} RShift {RShift} Alt {Alt} LAlt {LAlt} RAlt {RAlt} Control {Control} LControl {LControl} RControl {RControl} Ctrl {Ctrl} LCtrl {LCtrl} RCtrl {RCtrl} LWin {LWin} RWin {RWin} AppsKey {AppsKey} AltDown {AltDown} AltUp {AltUp} ShiftDown {ShiftDown} ShiftUp {ShiftUp} CtrlDown {CtrlDown} CtrlUp {CtrlUp} LWinDown {LWinDown} RWinDown {RWinDown} LButton {LButton} RButton {RButton} MButton {MButton} WheelUp {WheelUp} WheelDown {WheelDown} XButton1 {XButton1} XButton2 {XButton2} Joy1 {Joy1} Joy2 {Joy2} Joy3 {Joy3} Joy4 {Joy4} Joy5 {Joy5} Joy6 {Joy6} Joy7 {Joy7} Joy8 {Joy8} Joy9 {Joy9} Joy10 {Joy10} Joy11 {Joy11} Joy12 {Joy12} Joy13 {Joy13} Joy14 {Joy14} Joy15 {Joy15} Joy16 {Joy16} Joy17 {Joy17} Joy18 {Joy18} Joy19 {Joy19} Joy20 {Joy20} Joy21 {Joy21} Joy22 {Joy22} Joy23 {Joy23} Joy24 {Joy24} Joy25 {Joy25} Joy26 {Joy26} Joy27 {Joy27} Joy28 {Joy28} Joy29 {Joy29} Joy30 {Joy30} Joy31 {Joy31} Joy32 {Joy32} JoyX {JoyX} JoyY {JoyY} JoyZ {JoyZ} JoyR {JoyR} JoyU {JoyU} JoyV {JoyV} JoyPOV {JoyPOV} JoyName {JoyName} JoyButtons {JoyButtons} JoyAxes {JoyAxes} JoyInfo {JoyInfo} Space {Space} Tab {Tab} Enter {Enter} Escape {Escape} Esc {Esc} BackSpace {BackSpace} BS {BS} Delete {Delete} Del {Del} Insert {Insert} Ins {Ins} PGUP {PGUP} PGDN {PGDN} Home {Home} End {End} Up {Up} Down {Down} Left {Left} Right {Right} PrintScreen {PrintScreen} CtrlBreak {CtrlBreak} Pause {Pause} ScrollLock {ScrollLock} CapsLock {CapsLock} NumLock {NumLock} Numpad0 {Numpad0} Numpad1 {Numpad1} Numpad2 {Numpad2} Numpad3 {Numpad3} Numpad4 {Numpad4} Numpad5 {Numpad5} Numpad6 {Numpad6} Numpad7 {Numpad7} Numpad8 {Numpad8} Numpad9 {Numpad9} NumpadMult {NumpadMult} NumpadAdd {NumpadAdd} NumpadSub {NumpadSub} NumpadDiv {NumpadDiv} NumpadDot {NumpadDot} NumpadDel {NumpadDel} NumpadIns {NumpadIns} NumpadClear {NumpadClear} NumpadUp {NumpadUp} NumpadDown {NumpadDown} NumpadLeft {NumpadLeft} NumpadRight {NumpadRight} NumpadHome {NumpadHome} NumpadEnd {NumpadEnd} NumpadPgup {NumpadPgup} NumpadPgdn {NumpadPgdn} NumpadEnter {NumpadEnter} F1 {F1} F2 {F2} F3 {F3} F4 {F4} F5 {F5} F6 {F6} F7 {F7} F8 {F8} F9 {F9} F10 {F10} F11 {F11} F12 {F12} F13 {F13} F14 {F14} F15 {F15} F16 {F16} F17 {F17} F18 {F18} F19 {F19} F20 {F20} F21 {F21} F22 {F22} F23 {F23} F24 {F24} Browser_Back {Browser_Back} Browser_Forward {Browser_Forward} Browser_Refresh {Browser_Refresh} Browser_Stop {Browser_Stop} Browser_Search {Browser_Search} Browser_Favorites {Browser_Favorites} Browser_Home {Browser_Home} Volume_Mute {Volume_Mute} Volume_Down {Volume_Down} Volume_Up {Volume_Up} Media_Next {Media_Next} Media_Prev {Media_Prev} Media_Stop {Media_Stop} Media_Play_Pause {Media_Play_Pause} Launch_Mail {Launch_Mail} Launch_Media {Launch_Media} Launch_App1 {Launch_App1} Launch_App2 {Launch_App2} F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12';
	var functions = 'RegExMatch RegExReplace InStr SubStr NumGet NumPut';

	this.regexList = [
		{ regex: SyntaxHighlighter.regexLib.multiLineCComments,		css: 'comments' },  	// multiline comments 
		{ regex: /(^;.+$)|(\s;.+$)/gm,								css: 'comments' },  	// one line
		{ regex: SyntaxHighlighter.regexLib.doubleQuotedString,		css: 'string' },		// strings
		{ regex: /^ *#.*/gm,										css: 'directives'},		// directives
		{ regex: /\b[\d\.]+\b/g,									css: 'value' },			// numbers 12345
		{ regex: /\0x[a-zA-Z0-9]+\b/g,								css: 'value' },			// numbers 0x5D3
		{ regex: /%[a-zA-Z0-9]+%/g,									css: 'variable'},		// variable
		{ regex: /^\s*[a-zA-Z0-9]+\:\s*$/gm,						css: 'label'},			// labels
		{ regex: /^\s*[a-zA-Z0-9]+\:\:/g,							css: 'hotkey'},			// labels
		{ regex: /^\b[a-zA-Z0-9]+\(/g,								css: 'funcalls'},		// funcalls
		{ regex: new RegExp(this.getKeywords(commands), 'gmi'),		css: 'commands' },		// keyword
		{ regex: new RegExp(this.getKeywords(special), 'gmi'),		css: 'special' },		// keyword
		{ regex: new RegExp(this.getKeywords(keys), 'gmi'),			css: 'keys' },			// keyword
		{ regex: new RegExp(this.getKeywords(functions), 'gmi'),	css: 'functions' }		// keyword
		];
};

SyntaxHighlighter.brushes.AHK.prototype	= new SyntaxHighlighter.Highlighter();
SyntaxHighlighter.brushes.AHK.aliases	= ['AutoHotKey', 'ahk'];
