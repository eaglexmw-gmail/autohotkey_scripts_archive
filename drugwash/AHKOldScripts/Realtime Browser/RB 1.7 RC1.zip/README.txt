			REALTIME BROWSER README FILE  
,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,


PLEASE READ THIS FILE CAREFULLY. IT CONTAINS IMPORTANT INFORMATIONS

LICENSE
Realtime Browser and PHP is licensed under the GNU General Public License.
For more informations see file 'license.txt' located in realtime browser directory.

REQUIREMENTS
Realtime Browser requires minimal Internet Explorer 5.5
Operating Systems: Win XP/Windows Vista/Win 2000/Win 2003 Server/Win 2008 Server/Win XP Media Center Edition

DONATE
..............................
If you like realtime browser, Please donate.
Just visit the following URL, to donate via PayPal:

http:/www.xptricks.de/donate

Thanks if you�ve donated! You help me, to publish new Versions of RB!

SPECIAL KEYS
..............................
CLOSE A TAB | Position your mouse over a tab, click with the middle mouse button, finished!


TOOLTIPS
...........................
There are some short Informations about special buttons, just keep your mouse a few seconds over a control...
now there should apper a short tooltip with informations.

PLUGINS
You can write your own plugins.
For more information see here: http://forum.xptricks.de


END OF README
-----------------------


� by Dominik Hardtke.