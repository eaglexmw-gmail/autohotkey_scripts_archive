			REALTIME BROWSER README FILE  


PLEASE READ THIS FILE CAREFULLY. IT CONTAINS IMPORTANT INFORMATIONS

LICENSE
Realtime Browser is licensed under the GNU General Public License.
For more informations see file 'license.txt' located in realtime browser directory.

REQUIREMENTS
Realtime Browser requires min Internet Explorer 5.5
Operating Systems: Win XP/Windows Vista/Win 2000/Win 2003 Server/Win 2008 Server/Win XP Media Center Edition

DONATE
If you like realtime browser, Please donate.
Just visit the following URL, to Donate with PayPal:

http://dhmh.bplaced.net/donate

Thanks if you�ve donated! You help me, to publish new Versions of RB!

SPECIAL KEYS
CLOSE A TAB | Position your mouse over a tab, click with the middle mouse button, finished!


TOOLTIPS
There are some short Informations about special buttons, just keep your mouse a few seconds over a control...
now there should apper a short tooltip with informations.



_____________________   _____  .____  ___________.___   _____  ___________
\______   \_   _____/  /  _  \ |    | \__    ___/|   | /     \ \_   _____/
 |       _/|    __)_  /  /_\  \|    |   |    |   |   |/  \ /  \ |    __)_ 
 |    |   \|        \/    |    \    |___|    |   |   /    Y    \|        \
 |____|_  /_______  /\____|__  /_______ \____|   |___\____|__  /_______  /
        \/        \/         \/        \/                    \/        \/ 
____________________ ________  __      __  ______________________________ 
\______   \______   \\_____  \/  \    /  \/   _____/\_   _____/\______   \
 |    |  _/|       _/ /   |   \   \/\/   /\_____  \  |    __)_  |       _/
 |    |   \|    |   \/    |    \        / /        \ |        \ |    |   \
 |______  /|____|_  /\_______  /\__/\  / /_______  //_______  / |____|_  /
        \/        \/         \/      \/          \/         \/         \/ 

..........................................................................................
_________                             .__       .__     __    ___.          
\_   ___ \  ____ ______ ___.__._______|__| ____ |  |___/  |_  \_ |__ ___.__.
/    \  \/ /  _ \\____ <   |  |\_  __ \  |/ ___\|  |  \   __\  | __ <   |  |
\     \___(  <_> )  |_> >___  | |  | \/  / /_/  >   Y  \  |    | \_\ \___  |
 \______  /\____/|   __// ____| |__|  |__\___  /|___|  /__|    |___  / ____|
        \/       |__|   \/              /_____/      \/            \/\/     
________                 .__       .__ __       ___ ___                  .___ __   __           
\______ \   ____   _____ |__| ____ |__|  | __  /   |   \_____ _______  __| _//  |_|  | __ ____  
 |    |  \ /  _ \ /     \|  |/    \|  |  |/ / /    ~    \__  \\_  __ \/ __ |\   __\  |/ // __ \ 
 |    `   (  <_> )  Y Y  \  |   |  \  |    <  \    Y    // __ \|  | \/ /_/ | |  | |    <\  ___/ 
/_______  /\____/|__|_|  /__|___|  /__|__|_ \  \___|_  /(____  /__|  \____ | |__| |__|_ \\___  >
        \/             \/        \/        \/        \/      \/           \/           \/    \/ 




END OF README
-----------------------


� by Dominik Hardtke.