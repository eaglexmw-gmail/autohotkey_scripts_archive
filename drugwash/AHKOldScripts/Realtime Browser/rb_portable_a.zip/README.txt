			REALTIME BROWSER README FILE  


PLEASE READ THIS FILE CAREFULLY. IT CONTAINS IMPORTANT INFORMATIONS

LICENSE
Realtime Browser is licensed under the GNU General Public License.
For more informations see file 'license.txt' located in realtime browser directory.

REQUIREMENTS
Realtime Browser requires min Internet Explorer 5.5
Operating Systems: Win XP/Windows Vista/Win 2000/Win 2003 Server/Win 2008 Server/Win XP Media Center Edition

DONATE
If you like realtime browser, Please donate.
Just visit the following URL, to Donate with PayPal:

http://dhmh.bplaced.net/donate

Thanks if you�ve donated! You help me, to publish new Versions of RB!





END OF README
-----------------------




� by Dominik Hardtke.