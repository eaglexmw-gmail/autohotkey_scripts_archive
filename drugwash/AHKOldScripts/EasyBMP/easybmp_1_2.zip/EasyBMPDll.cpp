// EasyBMP license (and thus the license for the DLL and the AHK wrapper):
/*
Copyright (c) 2005, The EasyBMP Project (http://easybmp.sourceforge.net)
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

	1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
	2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
		in the documentation and/or other materials provided with the distribution.
	3. The name of the author may not be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING,
BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

// It needs:
// EasyBMP 1.06: http://prdownloads.sourceforge.net/easybmp/EasyBMP_1.06.zip?download
// EasyBMP Extensions Package 1.05: http://prdownloads.sourceforge.net/easybmp/EasyBMP_extensions_1.05.00.zip?download

// Windows includes
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

// EasyBMP includes
#include "EasyBMP.h"
#include "EasyBMP_Geometry.h"
#include "EasyBMP_Font.h"
#include "EasyBMP_win32.h"

// The following is copied from my own <dll.h> header :3
#ifdef __cplusplus /* C++ */
#define DllFunc extern "C" __declspec(dllexport)
#else /* C */
#define DllFunc __declspec(dllexport)
#endif

// Defines
#define BMP_RESIZE_SCALE 0
#define BMP_RESIZE_W     1
#define BMP_RESIZE_H     2
#define BMP_RESIZE_FIT   3

// Structures
typedef struct{
	int w;
	int h;
	int hdpi;
	int vdpi;
	int bitdepth;
	int colors;
}BMPInfo;

typedef struct{
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char a;
}BMPPixel;

typedef struct{
	int x;
	int y;
}BMPPixelPos;

typedef struct{
	int x;
	int y;
	int w;
	int h;
}BMPPixelRange;

typedef struct{
	double CenterX;
	double CenterY;
	double Radius;
	double StartAngle;
	double EndAngle;
}BMPArc;

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved){
	switch(ul_reason_for_call){
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
	}
	SetEasyBMPwarningsOff();
	return TRUE;
}

DllFunc BMP* BMP_Create(){
	BMP* hBMP = new BMP();
	return hBMP;
}

DllFunc BMP* BMP_CreateEx(BMP* input){
	BMP* hBMP = new BMP(*input);
	return hBMP;
}

DllFunc void BMP_Delete(BMP* hBMP){
	delete hBMP;
}

DllFunc bool BMP_LoadFile(BMP* hBMP, char* szFilename){
	return hBMP->ReadFromFile(szFilename);
}

DllFunc bool BMP_SaveFile(BMP* hBMP, char* szFilename){
	return hBMP->WriteToFile(szFilename);
}

DllFunc void BMP_PixelGet(BMP* hBMP, BMPPixel* hPixel, BMPPixelPos* hPixelPos){
	int x = hPixelPos->x, y = hPixelPos->y;
	hPixel->r = hBMP->GetPixel(x, y).Red;
	hPixel->g = hBMP->GetPixel(x, y).Green;
	hPixel->b = hBMP->GetPixel(x, y).Blue;
	hPixel->a = hBMP->GetPixel(x, y).Alpha;
}

DllFunc bool BMP_PixelSet(BMP* hBMP, BMPPixel* hPixel, BMPPixelPos* hPixelPos){
	int x = hPixelPos->x, y = hPixelPos->y;
	RGBApixel oNewPixel;
	oNewPixel.Red = hPixel->r;
	oNewPixel.Green = hPixel->g;
	oNewPixel.Blue = hPixel->b;
	oNewPixel.Alpha = hPixel->a;
	return hBMP->SetPixel(x, y, oNewPixel);
}

DllFunc void BMP_GetInfo(BMP* hBMP, BMPInfo* hBMPInfo){
	hBMPInfo->w = hBMP->TellWidth();
	hBMPInfo->h = hBMP->TellHeight();
	hBMPInfo->hdpi = hBMP->TellHorizontalDPI();
	hBMPInfo->vdpi = hBMP->TellVerticalDPI();
	hBMPInfo->bitdepth = hBMP->TellBitDepth();
	hBMPInfo->colors = hBMP->TellNumberOfColors();
}

DllFunc bool BMP_SetSize(BMP* hBMP, int width, int height){
	return hBMP->SetSize(width, height);
}

DllFunc bool BMP_SetBitDepth(BMP* hBMP, int bitdepth){
	return hBMP->SetBitDepth(bitdepth);
}

DllFunc void BMP_SetDPI(BMP* hBMP, int hdpi, int vdpi){
	hBMP->SetDPI(hdpi, vdpi);
}

// Internal CopyPixel function that is called if BMP_CopyPixelRange is called with w=1 and h=1.
void _BMP_CopyPixel(BMP* hBMP1, BMP* hBMP2, BMPPixelPos* hPixelPos1, BMPPixelPos* hPixelPos2, BMPPixel* hTransColor){
	int x1 = hPixelPos1->x, y1 = hPixelPos1->y, x2 = hPixelPos2->x, y2 = hPixelPos2->y;
	if(hTransColor == NULL)
		PixelToPixelCopy(*hBMP1, x1, y1, *hBMP2, x2, y2);
	else{
		RGBApixel oNewPixel;
		oNewPixel.Red = hTransColor->r;
		oNewPixel.Green = hTransColor->g;
		oNewPixel.Blue = hTransColor->b;
		oNewPixel.Alpha = hTransColor->a;
		PixelToPixelCopyTransparent(*hBMP1, x1, y1, *hBMP2, x2, y2, oNewPixel);
	}
}

DllFunc void BMP_CopyPixelRange(BMP* hBMP1, BMP* hBMP2, BMPPixelRange* hPixelRange, BMPPixelPos* hPixelPos, BMPPixel* hTransColor){
	if((hPixelRange->w == 0) && (hPixelRange->h == 0)){
		BMPPixelPos newPos = {hPixelRange->x, hPixelRange->y};
		_BMP_CopyPixel(hBMP1, hBMP2, &newPos, hPixelPos, hTransColor);
		return;
	}
	int s_l = hPixelRange->x, s_t = hPixelRange->y, s_r = s_l + hPixelRange->w - 1, s_b = s_t + hPixelRange->h - 1;
	int x = hPixelPos->x, y = hPixelPos->y;
	if(hTransColor == NULL)
		RangedPixelToPixelCopy(*hBMP1, s_l, s_r, s_b, s_t, *hBMP2, x, y);
	else{
		RGBApixel oNewPixel;
		oNewPixel.Red = hTransColor->r;
		oNewPixel.Green = hTransColor->g;
		oNewPixel.Blue = hTransColor->b;
		oNewPixel.Alpha = hTransColor->a;
		RangedPixelToPixelCopyTransparent(*hBMP1, s_l, s_r, s_b, s_t, *hBMP2, x, y, oNewPixel);
	}
}

DllFunc void BMP_FillRange(BMP* hBMP, BMPPixelRange* hRange, BMPPixel* hColor){
	BMPPixelPos oPos;
	for(int y = hRange->y; y <= (hRange->y+hRange->h-1); y ++){
		for(int x = hRange->x; x <= (hRange->x+hRange->w-1); x ++){
			oPos.x = x, oPos.y = y;
			BMP_PixelSet(hBMP, hColor, &oPos);
		}
	}
}

DllFunc bool BMP_Resize(BMP* hBMP, int mode, int param){
	char* szModes = "pWHf";
	if(!((mode >= 0) && (mode <= 3)))
		return false;
	return Rescale(*hBMP, szModes[mode], param);
}

DllFunc void Geometry_DrawLine(BMP* hBMP, BMPPixel* hColor, BMPPixelPos* hFrom, BMPPixelPos* hTo, bool antialias){
	int x1 = hFrom->x, y1 = hFrom->y, x2 = hTo->x, y2 = hTo->y;
	RGBApixel oNewPixel;
	oNewPixel.Red = hColor->r;
	oNewPixel.Green = hColor->g;
	oNewPixel.Blue = hColor->b;
	oNewPixel.Alpha = hColor->a;
	if(antialias)
		DrawLine(*hBMP, x1, y1, x2, y2, oNewPixel);
	else
		DrawFastLine(*hBMP, x1, y1, x2, y2, oNewPixel);
}

DllFunc void Geometry_DrawArc(BMP* hBMP, BMPPixel* hColor, BMPArc* hArc){
	RGBApixel oNewPixel;
	oNewPixel.Red = hColor->r;
	oNewPixel.Green = hColor->g;
	oNewPixel.Blue = hColor->b;
	oNewPixel.Alpha = hColor->a;
	DrawArc(*hBMP, hArc->CenterX, hArc->CenterY, hArc->Radius, hArc->StartAngle, hArc->EndAngle, oNewPixel);
}

DllFunc int Text_DrawString(BMP* hBMP, BMPPixel* hColor, BMPPixelPos* hWhere, int height, char* szString){
	int x = hWhere->x, y = hWhere->y;
	RGBApixel oNewPixel;
	oNewPixel.Red = hColor->r;
	oNewPixel.Green = hColor->g;
	oNewPixel.Blue = hColor->b;
	oNewPixel.Alpha = hColor->a;
	return PrintString(*hBMP, szString, x, y, height, oNewPixel);
}

DllFunc BMP* Win32_CreateBMPfromHBITMAP(HBITMAP hBitmap, HDC hDC){
	BMP* hBMP = BMP_Create();
	if(hDC == NULL) hDC = GetDC(NULL);
	if(!hBMP)
		return NULL;
	if(!HBITMAPtoBMP(hDC, hBitmap, *hBMP))
		return NULL;
	else
		return hBMP;
}

DllFunc HBITMAP Win32_CreateHBITMAPfromBMP(BMP* hBMP, HDC hDC){
	if(hDC == NULL) hDC = GetDC(NULL);
	return BMPtoHBITMAP(hDC, *hBMP);
}

DllFunc bool Win32_Screenshot(BMP* hBMP, HWND hWnd){
	if(hWnd == NULL)
		return CaptureScreen(*hBMP);
	else
		return CaptureWindow(hWnd, *hBMP);
}
