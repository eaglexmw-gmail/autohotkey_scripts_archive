Controls:

double click on thumbnail		Zoom in, mouse click at center
double right click on thumbnail		Zoom out, mouse click at center
left click on thumbnail			Re-center on mouse click

double click on full view		save
double right click on full view		open in windows picture and fax viewer

Full Render button			renders full size image of thumbnail
Thumbnail button			re-renders thumbnail (for manual changes)
color mode				changes color interpretation

xmin, xmax, ymin, ymax			the location of the region, updates automatically
width, height				the width and height of the full render (thumb is always 150x150)
depth					the number of times to iterate

theory:
some of the info here may be confusing without a good mathematical background.
the mandelbrot set is the region of points for which
	(z(n) = z(n-1) + c)
stays bounded as n approaches infinity.  we cannot approach infinity, so we stop at depth.

general:
img.exe programmed in C++, compiled with MinGW
mandelbrot.exe programmed in AHK
fractal.ico created by program written in pure AHK