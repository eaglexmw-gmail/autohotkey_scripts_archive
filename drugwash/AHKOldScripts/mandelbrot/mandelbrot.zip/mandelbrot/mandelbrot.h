
unsigned char mbrot_red(double v, int method);
unsigned char mbrot_grn(double v, int method);
unsigned char mbrot_blu(double v, int method);

double CheckMandel(double r, double i, int d);
bmp_image * RenderMbrot(double xmin, double xmax, double ymin, double ymax, int wpix, int hpix, int depth);

double CheckMandel(double r, double i, int d)
{
  double rr=0,ii=0,rx,ix;
  int j;
  for (j=1; j<=d; j++)
  {
    rx=rr*rr-ii*ii+r;
    ix=2*ii*rr+i;
    rr=rx;ii=ix;
    if (rr*rr+ii*ii>4)
    {
      rx=rr*rr-ii*ii+r;
      ix=2*ii*rr+i;
      rr=rx;ii=ix;
      rx=rr*rr-ii*ii+r;
      ix=2*ii*rr+i;
      rr=rx;ii=ix;
      rx=rr*rr-ii*ii+r;
      ix=2*ii*rr+i;
      rr=rx;ii=ix;
      double v=j+3+(log(2*log(2))-log(log(sqrt(rr*rr+ii*ii))))/log(2);
      return v;
    }
  }
  return 0;
}

bmp_image * RenderMbrot(double xmin, double xmax, double ymin, double ymax, int wpix, int hpix, int depth, int method)
{
  int w,h,x,y;  
  unsigned int i;
  double pct, result;
  printf("\n");
  bmp_image * mandelbrot = new bmp_image(wpix, hpix, 24);
  for (h=1; h<=hpix; h++)
  {
    for (w=1; w<=wpix; w++)
    {
      result = CheckMandel(xmin+w*(xmax-xmin)/(wpix-1),ymin+h*(ymax-ymin)/(hpix-1),depth); i = mandelbrot->index(w, h);
      mandelbrot->data[i]=mbrot_red(result, method);
      mandelbrot->data[i+1]=mbrot_grn(result, method);
      mandelbrot->data[i+2]=mbrot_blu(result, method);
    }
    pct = (100.0 * h / hpix);
    printf("\r%.2f%%", pct);
  }
  printf("\n");
  return mandelbrot;
}

//color interpretation for RGB, tweaking these is fun and results in new color schemes
unsigned char mbrot_red(double v, int method)
{
  if (v == 0) {return 0;}
  if (method==0)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/6), 2));}
  if (method==1)  {return (unsigned char) floor(255*pow(sin((sqrt(v)*3.141592)/6), 2));}
  if (method==2)  {return (unsigned char) floor(255*pow(sin((log(v)*3.141592)/6), 2));}
  if (method==3)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/3), 2));}
  if (method==4)  {return (unsigned char) floor(255*(1-pow(sin((v*3.141592)/6), 2)));}
  if (method==5)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.25)*3.141592)/6), 2));}
  if (method==6)  {return (unsigned char) floor(255*pow(sin((pow(v,1.0/3.0)*3.141592)/6), 2));}
  if (method==7)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.125)*3.141592)/6), 2));}
  if (method==8)  {return (unsigned char) floor(255*(1-pow(sin((2*log(v)*3.141592)/12), 2)));}
  if (method==9)  {return (unsigned char) floor(255*(1-pow(sin((sqrt(v)*3.141592)/12), 2)));}
}

unsigned char mbrot_blu(double v, int method)
{
  if (v == 0) {return 0;}
  if (method==0)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/6+2), 2));}
  if (method==1)  {return (unsigned char) floor(255*pow(sin((sqrt(v)*3.141592)/6+2), 2));}
  if (method==2)  {return (unsigned char) floor(255*pow(sin((log(v)*3.141592)/6+2), 2));}
  if (method==3)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/6+2), 2));}
  if (method==4)  {return (unsigned char) floor(255*(1-pow(sin((v*3.141592)/6+2), 2)));}
  if (method==5)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.25)*3.141592)/6+2), 2));}
  if (method==6)  {return (unsigned char) floor(255*pow(sin((pow(v,1.0/3.0)*3.141592)/6+2), 2));}
  if (method==7)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.125)*3.141592)/6+2), 2));}
  if (method==8)  {return (unsigned char) floor(255*(1-pow(sin((2*log(v)*3.141592)/6+2), 2)));}
  if (method==9)  {return (unsigned char) floor(255*(1-pow(sin((pow(v,1.0/3.0)*3.141592)/6+2), 2)));}
}

unsigned char mbrot_grn(double v, int method)
{
  if (v == 0) {return 0;}
  if (method==0)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/6+4), 2));}
  if (method==1)  {return (unsigned char) floor(255*pow(sin((sqrt(v)*3.141592)/6+4), 2));}
  if (method==2)  {return (unsigned char) floor(255*pow(sin((log(v)*3.141592)/6+4), 2));}
  if (method==3)  {return (unsigned char) floor(255*pow(sin((v*3.141592)/12+4), 2));}
  if (method==4)  {return (unsigned char) floor(255*(1-pow(sin((v*3.141592)/6+4), 2)));}
  if (method==5)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.25)*3.141592)/6+4), 2));}
  if (method==6)  {return (unsigned char) floor(255*pow(sin((pow(v,1.0/3.0)*3.141592)/6+4), 2));}
  if (method==7)  {return (unsigned char) floor(255*pow(sin((log(v)/log(1.125)*3.141592)/6+4), 2));}
  if (method==8)  {return (unsigned char) floor(255*(1-pow(sin((2*log(v)*3.141592)/3+4), 2)));}
  if (method==9)  {return (unsigned char) floor(255*(1-pow(sin((pow(v,.25)*3.141592)/3+4), 2)));}
}
