#include <sstream>
#include <string>
#include <stdio.h>
#include <math.h>
#include "bmp_image class.h"
#include "mandelbrot.h"

int main(int argc, char *argv[])
{
  int i, t=0;
  char xmin[32], xmax[32], ymin[32], ymax[32], depth[24], width[10], height[10], method[3];
  char * name;
  for (i=1;i<argc;i++)
  {
    if (!strcmp(argv[i],"-o"))  {t++; i++; name = argv[i];}
    else if (!strcmp(argv[i], "-xmin"))  {t++; i++; strcpy(xmin, argv[i]);}
    else if (!strcmp(argv[i], "-xmax"))  {t++; i++; strcpy(xmax, argv[i]);}
    else if (!strcmp(argv[i], "-ymin"))  {t++; i++; strcpy(ymin, argv[i]);}
    else if (!strcmp(argv[i], "-ymax"))  {t++; i++; strcpy(ymax, argv[i]);}
    else if (!strcmp(argv[i], "-w"))  {t++; i++; strcpy(width, argv[i]);}
    else if (!strcmp(argv[i], "-h"))  {t++; i++; strcpy(height, argv[i]);}
    else if (!strcmp(argv[i], "-d"))  {t++; i++; strcpy(depth, argv[i]);}
    else if (!strcmp(argv[i], "-cm"))  {t++; i++; strcpy(method, argv[i]);}
  }
  if (t != 9)
  {
    printf("Error: not enough parameters");
    return 1;
  }
  double xmin_, xmax_, ymin_, ymax_;
  int width_, height_, depth_, method_;
  istringstream convertxmin(xmin), convertxmax(xmax), convertymin(ymin), convertymax(ymax), convertwidth(width), convertheight(height), convertdepth(depth), convertmethod(method);
  convertxmin >> xmin_; convertxmax >> xmax_; convertymin >> ymin_; convertymax >> ymax_; convertwidth >> width_; convertheight >> height_; convertdepth >> depth_; convertmethod >> method_;
  if (width_==0&&height_==0) {printf("Cannot scale from a 0x0 image"); return 1;}
  if (width_==0) {width_=(int) floor((height_*(xmax_-xmin_))/(ymax_-ymin_)+.5);}
  if (height_==0) {height_=(int) floor((width_*(ymax_-ymin_))/(xmax_-xmin_)+.5);}
  printf("file: %s\ncorners: (%f, %f) and (%f, %f)\nsize: %ix%ipx\ndepth: %i", name, xmin_, ymax_, xmax_, ymin_, width_, height_, depth_);
  bmp_image * mm = RenderMbrot(xmin_, xmax_, ymin_, ymax_, width_, height_, depth_, method_);
  mm->bmp_save(name);
  printf("Finished rendering.");
  mm->~bmp_image();
  delete mm;
  return 0;
}
