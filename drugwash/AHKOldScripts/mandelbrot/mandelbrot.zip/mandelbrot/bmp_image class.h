
class bmp_image
{
  protected:
  //file header data
  unsigned short magic;
  unsigned int size;
  unsigned short res_1;
  unsigned short res_2;
  unsigned int offset;
  
  //image header data (not the same thing)
  unsigned int hsize;
  unsigned int width;
  unsigned int height;
  unsigned short c_planes;
  unsigned short bit_depth;
  unsigned int c_method;
  unsigned int datasize;
  unsigned int hres;
  unsigned int vres;
  unsigned int p_entries;
  unsigned int p_entries_vital;
  public:
  
  //actual bitmap data
  unsigned char * data;
  
  //constructor & destructor
  bmp_image(unsigned int width, unsigned int height, unsigned short bit_depth);
  bmp_image();
  ~bmp_image();

  //finds array position for w and h
  unsigned int index(int width, int height);
  
  //fetches other things
  short get_depth();
  bool set_depth();
  bool bmp_resize();
  int get_width();
  int get_height();
  long get_res();
  bool set_res();
  bool bmp_save(char* name);
  unsigned int bmp_size();
  
  private:
  //important stuff
  unsigned int max_index;
};

bmp_image::bmp_image(unsigned int width, unsigned int height, unsigned short bit_depth)
{
  this->magic = 0x4D42;
  this->res_1 = 0x4F57;
  this->res_2 = 0x544F;
  this->offset = 0x00000036;
  this->hsize = 0x00000028;
  this->width = width;
  this->height = height;
  this->c_planes = 0x0001;
  this->bit_depth = bit_depth;
  this->c_method = 0x00000000;
  this->datasize = (unsigned int) ceil(bit_depth * width / 32.0) * 4 * height;
  this->max_index = (unsigned int) ceil(bit_depth * width / 32.0) * 4 * height;
  this->size = this->datasize + 54;
  this->vres = 72;
  this->hres = 72;
  this->p_entries = 0x00000000;
  this->p_entries_vital = 0x00000000;
  this->data = new unsigned char [this->datasize];
}

bmp_image::bmp_image() {}

bmp_image::~bmp_image()
{
  delete[] this->data;
}
  

unsigned int bmp_image::index(int width,int height)
{
  unsigned int val = (unsigned int) ((height - 1) * ceil(this->width * this->bit_depth / 32.0) * 4) + 3 * (width - 1);
  if (val >= this->max_index) {printf("Error: returned %08X at %ix%i\n", val, width, height);}
  return val;
}

unsigned int bmp_image::bmp_size()
{
  return this->size;
}

bool bmp_image::bmp_save(char name[256])
{
  FILE * mfile;
  mfile = fopen(name, "wb");
  int * ptr = (int *) this + 1;
  fwrite(this, 1, 2, mfile);
  fwrite((int*)this + 1, 4, 13, mfile); 
  fwrite(this->data, 1, this->datasize, mfile);
  fclose(mfile);
  return 0;
}
