Demo script1 - test_AGB1.ahk
Demo script2 - test_AGB34.ahk
custom dll - images.dll

The images.dll file contains the LoadDllImage function that is used by the AGB_LoadImgDll function in the AGB.ahk file. To add images to this dll file, use ResHacker and specify the resource type as RCDATA. Alternately, use ResHacker to modify the existing bmps3.dll file that currently contains images for use with the demo scripts. 
