Unzip contents to a Library folder

User functions (for all functions indexes start at 1):

Indexes "wrap":
Use 0 to specify the last item
Use -1 to specify the next to last
etc.

If index is greater than the menu size, then the menu size will be used for the index
If index is too negative such that after "wrapping" the value would not refer to
    a menu item (ex. -2 in a size 2 list), then 1 is used


For MenuNameOrHandle parameters, the input is assumed to be a menu handle if an
integer and a MenuName if not.

The Position (if included) for such functions can be one of these:
1) If an integer, the item's position (starts at 1)
2) "h" followed by the item's handle (an integer) - as returned from Menu_getMenuItemHandle

For hMenu parameters, the input MUST be a menu handle.  Also, the Position for
such functions do not "wrap" (but still start at 1)


For functions that have a ByPosition parameter
    specify -1 to treat MenuItem as an item handle
    specify 0 (or false) to treat MenuItem as a menu item name
    specify 1 (or true) to treat MenuItem as a position

If MenuItem is not a parameter, then these specify the return type.
other values are reserved for compatibility with future versions



Menu object functions (call Menu_getMenuObject to return the needed MenuObject):

Menu_getMenuName(MenuObject)
    returns the MenuName (as seen by AHK) - stored on menu creation

Menu_setUserDefinedSize(Size = "")
    if Size is not the empty string, sets the number of user-defined values (default 0)
    for the menu object

Note: this is a Class (as supported using my Class library) - requires Class.ahk
(found here, http://www.autohotkey.net/~animeaime/ClassLibrary/Class.ahk)

(or download the entire Class library from here
http://www.autohotkey.net/~animeaime/ClassLibrary/Class.ahk)

See attached MenuItem.ahk file for details on MenuItem object functions

See MenuLibraryTest.ahk for examples on how to associate your own values with a menu

Functions:

Menu_indexOf(MenuNameOrHandle, MenuItemName)
    returns index of MenuItemName in specified menu
    returns 0 if item is not found
    returns the empty string if MenuItemName is blank

Menu_Add(MenuName, MenuItemName = "", MenuItemLabel = "")
    mimics the behavior of Menu, MenuName, Add, MenuItemName, Label-or-Submenu
    The "P" (priority) parameter is not supported
    (returns the MenuItem object for the new item)

Menu_Insert(AtIndex, MenuName, MenuItemName = "", MenuItemLabel = "")
    mimics the behavior of Menu_Add except that the item will be inserted at the
    specified index.  Note: if the menu item already exists, the label will
    be updated but the menu item will not be moved
    (returns the MenuItem object for the new item)

Note: this function is not built-in and must be created (see included
    MenuWrapperTest.ahk for an example)

Menu_fixUpMenuLabel(AtIndex, MenuName, MenuItemName, MenuItemLabel)
    A function that is called (if MenuItemLabel = "") before adding or inserting
    a menu item that allows to set MenuItemLabel to a "custom value"


Menu_Move(MenuNameOrHandle, FromIndex, ToIndex)
    move a menu item within the same menu
    nothing is done if FromIndex = ToIndex
    (returns the MenuItem object for the moved item)

Menu_MoveEx(FromMenuName, FromIndex, ToMenuName, ToIndex, overwrite = true)
    move a menu item from one menu to another
    (returns the MenuItem object for the moved item)

    if FromMenuName = ToMenuName, a Menu_Move is done instead

    overwrite describes the action to take if the menu item already exists
    in the new menu

    if overwrite is "true", then the "from" menu's data (checked/unchecked, default
        the MenuItem object, etc.) is used.
    if overwrite is "false", then the "to" menu's data is used.

    Regardless, the "from" menu's label-or-submenu is used on the new item

    Note: you can use Menu_getMenuItemInfo to save the old menu data
        use Menu_getMenuItemName (or the API wrapper, Menu_getMenuString)
        to save the menu item name

Menu_Delete(MenuName, MenuItemName = "")
    mimics the behavior of Menu, MenuName, Delete [, MenuItemName]
    (returns a non-zero value on success)

Menu_DeleteMenu(MenuName)
    mimics the behavior of Menu, MenuName, Delete
    same as Menu_Delete(MenuName)
    (returns a non-zero value on success)

Menu_DeleteAll(MenuName)
    mimics the behavior of Menu, MenuName, DeleteAll
    (returns a non-zero value on success)

Menu_DeletePosition(MenuName, Position)
    delete the menu item at the specified Position in MenuName
    (returns a non-zero value on success)

Menu_Default(MenuNameOrHandle, MenuItem, ByPosition = true)
    sets the default item for the specified menu.
    Note: You can still use Menu, MenuName, Default, MenuItemName

    However, you can NOT use Menu, MenuName, Default to "clear" the default item.
    Use Menu_NoDefault(MenuName) instead

    if ByPosition is "true", MenuItem is interpreted as the item's position
    if ByPosition is "false", MenuItem is interpreted as the MenuItemName
    if ByPosition is -1, MenuItem is interpreted as the menu item's handle

Menu_NoDefault(MenuName)
    mimics the behavior of Menu, MenuName, NoDefault

Menu_getDefault(MenuNameOrHandle, ByPosition = true)
    returns the current default item for the specified menu

    ;for ByPosition
    ;specify -1 to return the menu item handle
    ;specify 0 (or false) to return the MenuItemName
    ;specify 1 (or true) to return the position (starts at 1)

    ;other values are reserved for compatibility with future versions

    if ByPosition is "true", the position (in the menu) for the default item is returned.
    0 is returned if there is no default item

    if ByPosition is "false", then the MenuItemName is returned
    The empty string is returned if there is no default item
    
    if ByPosition = -1, then the menu item handle is returned
    -1 is returned if there is no default item

Menu_GetMenuHandle(MenuName)
    wraps MI_getMenuHandle so even if menu doesn't exist, an error won't occur

Menu_Standard(MenuName)
    mimics the behavior of Menu, MenuName, Standard

Menu_NoStandard(MenuName)
    mimics the bevavior of Menu, MenuName, NoStandard

Menu_isChecked(MenuNameOrHandle, MenuItem, ByPosition = false)
    returns a non-zero value if menu item is checked
    returns the empty string if the menu's size is zero or if the item was not found

    ;for ByPosition
    ;specify -1 to treat MenuItem as an item handle
    ;specify 0 (or false) to treat MenuItem as a menu item name
    ;specify 1 (or true) to treat MenuItem as a position

    ;other values are reserved for compatibility with future versions

Menu_selectMenuItem(hMenuItem, hwnd = 0)
    Select the specified menu item.  You can retrieve an item handle from
    a call to Menu_getMenuItemHandle(MenuNameOrHandle, Position)

    Values for hwnd:
        0 - to click an AHK menu item
        the empty string ("") - to click the menu item in the Last Found Window
        else, the hwnd (window unique ID) for the window

Menu_Click(ClickCount = "")
    mimics the behavior of Menu,, Click, ClickCount.
    Specify 1 for ClickCount to allow a single-click to activate the tray menu's default menu item.
    Specify 2 for ClickCount to return to the default behavior (double-click)
    Specify 0 to disable clicking the tray icon from activating the tray menu's default menu item

    Regardless, the previous value for Menu_Click is returned

Menu_UseErrorLevel(UseErrorLevel = "")
    if UseErrorLevel is "true", calls Menu, tray, UseErrorLevel
    if UseErrorLevel is "false", calls Menu, tray, UseErrorLevel, off
    if UseerrorLevel is the empty string, nothing is done

    Regardless, the previous value for UseErrorLevel is returned

    Note: This function MUST be called instead of Menu, MenuName, UseErrorLevel [, off]
        to maintain correct value of Menu_UseErrorLevel
        (static value in function to store state - either on or off)


Menu API wrappers (index values start at 1 and "wrap"):

Menu_getMenuItemName(MenuNameOrHandle, Position)
    returns the MenuItemName for the menu item at the specified Position in the specified menu

Menu_getMenuItemHandle(MenuNameOrHandle, Position, ByRef ThisMenu = 0)
    returns the menu item's handle for the menu item at the specified Position in the specified menu
    (-1 is returned if the menu item opens a submenu, or if an invalid position is given)

    Position can be an integer,
        or a comma-delimited list of Positions (each that will "wrap")

    The list is the "road map" of menu items (all of which are submenus)
    that lead to the last position, which must be a menu item.

Menu_getMenuSize(MenuNameOrHandle)
    returns the size of the menu

    if the menu doesn't exist, an error will occur

Menu_getMenuSize_private(MenuName, ByRef hMenu = "")
    returns the size of the menu (stores the menu handle in hMenu, if specified)

    if the menu doesn't exist, hMenu is set to 0

Menu_getMenuObject(MenuNameOrHandle)
    returns the memory address for the Menu object for the specified menu
    (for use with Menu object functions)

Menu_getMenuItemObject(MenuNameOrHandle, Position)
    returns the memory address for the MenuItem object at the specified Position for the specified menu
    (for use with MenuItem object functions)


Menu API functions:
(indexes start at 1 and DON'T "wrap")
(also, hMenu MUST be a menu handle - not a menu name)

Menu_getMenuItemCount(hMenu)
    return the size of the menu

Menu_getMenuItemID(hMenu, Position)
    returns the menu item's handle for the menu item at the specified Position in the specified menu
    (-1 is returned if the menu item doesn't open a submenu)

Menu_getMenuString(hMenu, Position)
    returns the MenuItemName for the menu item at the specified Position in the specified menu

Menu_getMenu(hwnd = "")
    returns the menu handle for the menu bar of for the specified window

    the hwnd is the same as the window's unique ID
    (you can use a function call, i.e. WinExist, to retrieve this value)

    if hwnd is not specified (or 0), the Last Found Window will be used

Menu_getSubMenu(hMenu, Position)
    returns the handle for the submenu of the specified menu item
    (0 is returned if the menu item doesn't open a submenu)

Menu_getMenuInfo(hMenu, ByRef mi, fMask = 0x1F)
    returns a non-zero value on success
    (mi is created and holds the MenuInfo structure for the menu)
    (see the function for valid fMask values and description)

Menu_setMenuInfo(hMenu, ByRef mi)
    sets the MenuInfo structure to the already created MenuInfo structure
    (returns a non-zero value on success)

Menu_getMenuItemInfo(hMenu, Position, ByRef mii, fMask = 0x1AD)
    returns a non-zero value on success
    (mii is created and holds the MenuItemInfo structure for the menu)
    (see the function for valid fMask values and description)

Menu_setMenuItemInfo(hMenu, Position, ByRef mii)
    sets the MenuItemInfo structure to the already created MenuItemInfo structure
    (returns a non-zero value on success)
