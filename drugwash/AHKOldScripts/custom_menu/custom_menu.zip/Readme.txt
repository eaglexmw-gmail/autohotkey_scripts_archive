---------------------------------------------------------------
Custom Menu
---------------------------------------------------------------
by David Barnes - www.softwareguider.110mb.com
Copyright 2009. All rights reserved.

In order for this script to function correctly, it must first be extracted from its zip archive.

Included in this zip file are: custom_menu.ahk, custom_menu.exe and custom_menu.ico
If you want to view and learn from the code, open custom_menu.ahk
Otherwise, I prefer using custom_menu.exe